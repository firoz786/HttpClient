# Making video tutorials about HttpClient in C#

Youtube playlist: https://www.youtube.com/playlist?list=PLiG4KxH00ZpnmuSsIrQ3IGTUUfl_Gl1AH
