﻿using System.Net.Http;
using System.Threading.Tasks;

namespace TheConsole
{
    class Program
    {
        static async Task Main(string[] args)
        {

            var url = "https://localhost:5001/api/people";

            using (var httpClient = new HttpClient())
            {
                var response = await httpClient.GetAsync(url);
            }
        }
    }
}
